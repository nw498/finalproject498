$(document).ready(function(){
    $("#navbar-frame").load("navBar.html");
});
R:
1.  Final_Project_498_FCAST2_Baseline.R - R code for EDA and all models/techniques (excluding LightGBM)
2.  Final_Project_498_FCAST2_LightGBM.R - R code for EDA and LightGBM

FoodieWebApp:
1. Copy the war file on <tomcat-home>/webapps
2. Start tomcat and http://localhost:8080/forecast.jsp

FoodieMobilebApp:
1. Double click in apk-debug.apk on any Android device
2. Follow instructions to install it.



